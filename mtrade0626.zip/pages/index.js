import Link from 'next/link';
import { useState } from 'react';

export default function Home() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loggedIn, setLoggedIn] = useState(false);

  const handleLogin = () => {
    if (username === 'Monhuush' && password === 'Monhuush@9804') {
      setLoggedIn(true);
    } else {
      alert('Invalid login');
    }
  };

  if (loggedIn) {
    return (
      <div style={{ padding: 20 }}>
        <h1>Welcome, Monhuush</h1>
        <ul>
          <li><Link href="/chart">Trading Chart</Link></li>
          <li><Link href="/ai-chat">AI Chat</Link></li>
          <li><Link href="/journal">Trading Journal</Link></li>
          <li><Link href="/scanner">Market Scanner</Link></li>
        </ul>
      </div>
    );
  }

  return (
    <div style={{ padding: 20 }}>
      <h1>Login</h1>
      <input
        placeholder="Username"
        value={username}
        onChange={e => setUsername(e.target.value)}
        style={{ display: 'block', margin: '10px 0', padding: '8px', width: '100%' }}
      />
      <input
        placeholder="Password"
        type="password"
        value={password}
        onChange={e => setPassword(e.target.value)}
        style={{ display: 'block', margin: '10px 0', padding: '8px', width: '100%' }}
      />
      <button onClick={handleLogin} style={{ padding: '10px 20px' }}>Login</button>
    </div>
  );
}