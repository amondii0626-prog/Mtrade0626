export default function Chart() {
  return <h1 style={{padding:20}}>Trading Chart (TradingView integration placeholder)</h1>;
}