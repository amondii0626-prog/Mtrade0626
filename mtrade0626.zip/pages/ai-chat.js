export default function AIChat() {
  return <h1 style={{padding:20}}>AI Chat (AI integration placeholder)</h1>;
}