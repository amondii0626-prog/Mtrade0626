export default function Scanner() {
  return <h1 style={{padding:20}}>Market Scanner (SMC detection placeholder)</h1>;
}